var searchData=
[
  ['setappcontext',['setAppContext',['../group__Utility.html#gaa2e8b145888536c1c3196d45446a61db',1,'LE::Utility::setAppContext(::ANativeActivity const &amp;,::ndk_helper::JNIHelper const &amp;)'],['../group__Utility.html#gabfc53db6e5ead093908b8ea148963174',1,'LE::Utility::setAppContext(::ANativeActivity const &amp;)'],['../group__Utility.html#ga2d08b36685efbd357b2b3096d65a2792',1,'LE::Utility::setAppContext(::JavaVM &amp;,::jobject activity,::jobject assetManager)'],['../group__Utility.html#ga80170386a2a6775e9351a09eaf77e7be',1,'LE::Utility::setAppContext(::JavaVM &amp;,::jobject activity)']]],
  ['setpitchrange',['setPitchRange',['../classLE_1_1Meter_1_1PitchDetector.html#aa62dad42b0de35b8280d43f5fffee56a',1,'LE::Meter::PitchDetector']]],
  ['setup',['setup',['../classLE_1_1Meter_1_1PitchDetector.html#a4afc8667c953e45ab973a4624d94910d',1,'LE::Meter::PitchDetector']]]
];
