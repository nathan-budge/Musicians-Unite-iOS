var searchData=
[
  ['confidence',['confidence',['../structLE_1_1Meter_1_1PitchDetector_1_1Pitch.html#a62dc5621049754e717cdda1739872e46',1,'LE::Meter::PitchDetector::Pitch']]]
];
