var group__Utility =
[
    [ "SpecialLocations", "group__Utility.html#ga1b559153b33ec940c779c83b9a7a9aa0", [
      [ "AbsolutePath", "group__Utility.html#gga1b559153b33ec940c779c83b9a7a9aa0a079e2005afc59793ab640c39e74e9d06", null ],
      [ "AppData", "group__Utility.html#gga1b559153b33ec940c779c83b9a7a9aa0a326a60c098220692cf2216026a62c578", null ],
      [ "CWD", "group__Utility.html#gga1b559153b33ec940c779c83b9a7a9aa0a1d8e234bac59876f0edd1fe12092810c", null ],
      [ "Documents", "group__Utility.html#gga1b559153b33ec940c779c83b9a7a9aa0ae1167d094c9250290552074b0dc8743f", null ],
      [ "Library", "group__Utility.html#gga1b559153b33ec940c779c83b9a7a9aa0a1dd3b88ad8530c99b027cc386303764c", null ],
      [ "Resources", "group__Utility.html#gga1b559153b33ec940c779c83b9a7a9aa0a7182f2311c76e1ae82a8c4bc66235c05", null ],
      [ "ExternalStorage", "group__Utility.html#gga1b559153b33ec940c779c83b9a7a9aa0a49112bf3ab428dfb9c9482bc592c8f89", null ],
      [ "Temporaries", "group__Utility.html#gga1b559153b33ec940c779c83b9a7a9aa0a06bad4f3602391cb60c2b0af1dd2f4af", null ]
    ] ],
    [ "setAppContext", "group__Utility.html#gaa2e8b145888536c1c3196d45446a61db", null ],
    [ "setAppContext", "group__Utility.html#gabfc53db6e5ead093908b8ea148963174", null ],
    [ "setAppContext", "group__Utility.html#ga2d08b36685efbd357b2b3096d65a2792", null ],
    [ "setAppContext", "group__Utility.html#ga80170386a2a6775e9351a09eaf77e7be", null ]
];