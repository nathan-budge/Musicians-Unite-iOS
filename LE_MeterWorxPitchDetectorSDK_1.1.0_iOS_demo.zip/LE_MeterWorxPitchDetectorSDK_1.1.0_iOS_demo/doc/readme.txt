********************************************************************************
*
* Little Endian - MeterWorx(tm) PitchDetector SDK
*                                                                               
* Copyright (c) 2013 - 2015. by Little Endian Ltd. All rights reserved.                    
*
********************************************************************************

Thank you for your interest in Little Endian's MeterWorx PitchDetection SDK. 
In case you have questions, please contact us via our contact page: 
http://www.littleendian.com/contact.

To get started, please read the documentation.


Thank you,

the Little Endian team
www.LittleEndian.com

********************************************************************************
