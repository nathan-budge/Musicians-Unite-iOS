var modules =
[
    [ "Overview", "index.html#intro", null ],
    [ "Release Notes", "index.html#rnotes", null ],
    [ "Requirements", "index.html#requirements", null ],
    [ "Build configuration", "index.html#buildConfiguration", null ],
    [ "General usage and design notes", "index.html#usage", null ],
    [ "Demo limitation", "index.html#demo", null ],
    [ "Utility", "group__Utility.html", "group__Utility" ],
    [ "Meter", "group__Meter.html", "group__Meter" ]
];