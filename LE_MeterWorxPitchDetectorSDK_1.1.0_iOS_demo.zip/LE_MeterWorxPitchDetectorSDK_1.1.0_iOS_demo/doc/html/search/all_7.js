var searchData=
[
  ['meterworx_20pitchdetector_20sdk',['MeterWorx PitchDetector SDK',['../index.html',1,'']]],
  ['meter',['Meter',['../group__Meter.html',1,'']]]
];
